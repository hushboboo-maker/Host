OPENCHAT ANDROID LAN SERVER
============================

What this does
--------------
Your Android phone runs a small Python web server. Everyone on the same Wi-Fi
opens the host phone's local IP address in a browser. The phone serves the HTML
chatroom, relays messages, and stores the most recent 300 messages in history.json.

No Supabase, cloud database, Node.js, or Internet connection is required after
Termux and its Python package are installed. The Wi-Fi router must allow devices
to communicate with each other (some guest/school networks isolate devices).

Install on Android
------------------
1. Install Termux from F-Droid (https://f-droid.org/packages/com.termux/)
   or the official Termux GitHub releases. Do not use the obsolete Play Store build.
2. Open Termux and run:

   pkg update
   pkg install python unzip
   pip install aiohttp

3. Extract this ZIP into a folder on your phone, for example Download/openchat-android-server.
   In Termux, locate it. If needed:

   termux-setup-storage
   cd ~/storage/downloads/openchat-android-server

   (Folder capitalization must match what your phone shows.)

4. Start the server:

   python server.py

5. Termux prints one or more local addresses. On other devices connected to the
   same Wi-Fi, open:

   http://PHONE-IP:8080

6. Keep Termux open and the phone awake while hosting. To stop the server,
   press Ctrl+C in Termux.

Important notes
---------------
- This package is a Termux-hosted server, not a separately compiled APK.
  Termux itself is the Android app that runs it.
- Host and guests must be on the same local Wi-Fi. Mobile data will not let
  outside users join this LAN-only room.
- Do not expose port 8080 to the public Internet. This is intentionally a
  simple trusted-local-network chat, without login or advanced moderation.
- The server applies the restricted-word check itself as well as the browser.
- Message history is stored in history.json next to server.py.
- If the host phone sleeps aggressively, Android may pause Termux. Keep it
  charging and disable battery optimization for Termux during a chat session.
