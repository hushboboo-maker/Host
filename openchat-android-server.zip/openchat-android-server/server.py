#!/usr/bin/env python3
import asyncio
import json
import re
import socket
from datetime import datetime, timezone
from pathlib import Path

from aiohttp import web, WSMsgType

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "www"
HISTORY_FILE = ROOT / "history.json"
PORT = 8080
MAX_HISTORY = 300
clients = set()
history = []

# Simple server-side check. The browser also checks before sending.
BLOCKED = [
    re.compile(r"n[\W_]*i[\W_]*g[\W_]*g[\W_]*(?:a|e|u|y|er|uh)?", re.I),
    re.compile(r"f[\W_]*a[\W_]*g[\W_]*g[\W_]*o[\W_]*t", re.I),
]

def is_blocked(text):
    s = text.casefold()
    s = s.replace("0", "o").replace("@", "a").replace("1", "i")
    s = s.replace("!", "i").replace("3", "e").replace("4", "a").replace("$", "s")
    compact = re.sub(r"[^a-z]", "", s)
    return any(p.search(s) for p in BLOCKED) or any(
        token in compact for token in ("nigga", "nigger", "faggot")
    )

def local_ips():
    found = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in found:
                found.append(ip)
    except OSError:
        pass
    # Android devices sometimes don't resolve their Wi-Fi hostname.
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 80))
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("127.") and ip not in found:
            found.insert(0, ip)
    except OSError:
        pass
    return found

def load_history():
    global history
    try:
        data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            history = data[-MAX_HISTORY:]
    except (OSError, ValueError):
        history = []

def save_history():
    try:
        HISTORY_FILE.write_text(json.dumps(history[-MAX_HISTORY:], ensure_ascii=False), encoding="utf-8")
    except OSError as exc:
        print("Could not save history:", exc)

async def broadcast(payload):
    dead = []
    encoded = json.dumps(payload, ensure_ascii=False)
    for ws in list(clients):
        if ws.closed:
            dead.append(ws)
        else:
            try:
                await ws.send_str(encoded)
            except Exception:
                dead.append(ws)
    for ws in dead:
        clients.discard(ws)

async def index(_request):
    return web.FileResponse(WEB / "index.html")

async def status(_request):
    return web.json_response({"port": PORT, "ips": local_ips(), "members": len(clients)})

async def websocket_handler(request):
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=4096)
    await ws.prepare(request)
    clients.add(ws)
    await ws.send_json({"type": "history", "messages": history[-MAX_HISTORY:]})
    await broadcast({"type": "presence", "members": len(clients)})
    username = "Guest"
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                except ValueError:
                    continue
                if data.get("type") == "join":
                    username = re.sub(r"[<>\\r\\n]", "", str(data.get("name", "Guest")))[:24].strip() or "Guest"
                    await ws.send_json({"type": "joined", "name": username})
                    await broadcast({"type": "system", "text": username + " joined the room"})
                    await broadcast({"type": "presence", "members": len(clients)})
                elif data.get("type") == "message":
                    text = str(data.get("text", "")).strip()
                    if not text or len(text) > 1500:
                        continue
                    if is_blocked(text):
                        await ws.send_json({"type": "blocked", "text": "That message contains language this room does not allow."})
                        continue
                    item = {
                        "name": username,
                        "text": text,
                        "time": datetime.now(timezone.utc).isoformat()
                    }
                    history.append(item)
                    del history[:-MAX_HISTORY]
                    save_history()
                    await broadcast({"type": "message", "message": item})
            elif msg.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                break
    finally:
        clients.discard(ws)
        await broadcast({"type": "presence", "members": len(clients)})
        await broadcast({"type": "system", "text": username + " left the room"})
    return ws

async def on_startup(_app):
    load_history()

app = web.Application()
app.router.add_get("/", index)
app.router.add_get("/status", status)
app.router.add_get("/ws", websocket_handler)
app.on_startup.append(on_startup)
app.router.add_static("/static/", WEB)

if __name__ == "__main__":
    print("\\nOpenChat Android server")
    print("On this phone: http://127.0.0.1:%d" % PORT)
    for ip in local_ips():
        print("On same Wi-Fi: http://%s:%d" % (ip, PORT))
    print("Keep Termux open while people are chatting. Press Ctrl+C to stop.\\n")
    web.run_app(app, host="0.0.0.0", port=PORT, print=None)
